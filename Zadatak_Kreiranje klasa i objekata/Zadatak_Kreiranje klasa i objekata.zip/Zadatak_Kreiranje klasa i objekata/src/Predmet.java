public class Predmet {
    private String nazivPredmeta;

    public Predmet(String nazivPredmeta) {
        this.nazivPredmeta = nazivPredmeta;
    }

    public String getNazivPredmeta() { return nazivPredmeta; }
    public void setNazivPredmeta(String nazivPredmeta) { this.nazivPredmeta = nazivPredmeta; }
}